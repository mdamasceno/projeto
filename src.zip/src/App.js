import React, {Component} from "react";
import "./App.css";

// semana 3 -- class component

class App extends Component{

  constructor(props){
    super(props);

    this.state = {
      user: {
        email: 'marcos.damasceno@pucpr.edu.br',
        password: '123456'
      },
      email: '',
      password: '',
      message: ''
    }

    this.setEmail = this.setEmail.bind(this);
    this.setPass = this.setPass.bind(this);
    this.submit = this.submit.bind(this);
  }

  setEmail(event){
    var input = event.target.value;
    this.setState({email: input})
  }

  setPass(event){
    var input = event.target.value;
    this.setState({password: input})
  }

  submit(){
    if(this.state.user.email == this.state.email && this.state.user.password == this.state.password){
      this.setState({message: 'Acessado com sucesso!'});
    }else{
      this.setState({message: 'E-mail ou senha inválidos!'});
    }
  }

  render(){
    return(
      <div className="form">
        <h1>Login</h1>
        <input type="email" placeholder="E-mail" name="email" onChange={(e) => this.setEmail(e)}/>
        <input type="password" placeholder="Senha" name="password" onChange={(e) => this.setPass(e)}/>
        <button  onClick={this.submit}>Acessar</button>
        <p className="msg">{this.state.message}</p>
      </div>
    );
  }
}

export default App;
